DEFAULT_STRAVA_TOKEN_ID = "0"
STRAVA_TOKEN_API_ENDPOINT = "https://www.strava.com/oauth/token"
STRAVA_ACTIVITIES_API_ENDPOINT = "https://www.strava.com/api/v3/activities"

REQUEST_TIMEOUT = 30  # Timeout in seconds
